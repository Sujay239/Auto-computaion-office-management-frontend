package com.xpritam.auto_computation;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
