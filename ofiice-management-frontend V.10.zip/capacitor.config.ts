import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.xpritam.auto_computation',
  appName: 'auto_computation',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
