package com.xpritam.Auto_Computation;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
