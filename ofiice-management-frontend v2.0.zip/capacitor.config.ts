import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.xpritam.Auto_Computation',
  appName: 'Auto_Computation',
  webDir: 'dist'
};

export default config;
